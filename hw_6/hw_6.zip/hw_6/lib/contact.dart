class Contact {
  final String name;
  final String url;

  Contact({
    required this.name,
    required this.url,
  });
}